package day24miniproject;

public class InvalidEmployeeDataException extends RuntimeException {
    public InvalidEmployeeDataException(String s) {
        super(s);
    }
}
